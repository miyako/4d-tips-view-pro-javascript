var params = $4DEVAL(JSON Stringify:C1217($1));



spread.savePDF( function(blob) {
    var reader = new FileReader();
    reader.readAsDataURL(blob);
    reader.onloadend = function() {
      params.content = reader.result.substr(reader.result.indexOf(',') + 1);
      $4d[params.onloadend](params);
  }
},
function(e){
    params.error = e;
    $4d[params.onerror](params);
},
params.options);
